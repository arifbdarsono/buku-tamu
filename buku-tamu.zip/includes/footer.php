<hr>
    <p><a href="index.php">Kembali ke daftar tamu</a></p>
</body>
</html>