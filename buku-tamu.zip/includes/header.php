<!DOCTYPE html>
<html>
<head>
    <title>Buku Tamu</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: sans-serif; margin: 40px; }
        .card { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; }
        .info { font-size: 0.9em; color: #666; }
    </style>
</head>
<body>
    <h1>Buku Tamu</h1>
    <hr>